# MERN-Quiz-App
The MERN-Quiz-App is a place where users can come and attempt the quiz and get the result. Also,  Admin has access to add the Quiz on a front page and delete the user functionality . The Tech Stack used HTML, CSS, JavaScript, MongoDB, React, Redux, and Tailwind CSS. Deploy Link :https://mern-quiz-app-ten.vercel.app/
<i><h2>1) Landing Page</h2></i>
<img src="https://user-images.githubusercontent.com/97445870/183289413-d10a5133-4164-4720-ad86-cf2dc54c4a31.png"/>
<i><h2>2) Registration Page</h2></i>
<img src="https://user-images.githubusercontent.com/97445870/183289419-f87ff37b-3623-43b7-ba62-b0d3a00aee22.png"/>
<i><h2>3) Login Page</h2></i>
<img src="https://user-images.githubusercontent.com/97445870/183289643-388294e7-f5ae-42fc-b135-3b0c6e018aec.png"/>
<i><h2>4) User Profile Page</h2></i>
<img src="https://user-images.githubusercontent.com/97445870/183289427-5ec96a82-bac5-48eb-95ca-a3bc52f66c6c.png"/>
<i><h2>5) Admin Profile with All User's Details Page</h2></i>
<img src="https://user-images.githubusercontent.com/97445870/183289430-05895b5f-d208-4e47-8100-8f7b04d79505.png"/>
<i><h2>6) Add Quiz Page in which Admin Post the Quiz into the MongoDB Database</h2></i>
<img src="https://user-images.githubusercontent.com/97445870/183289441-0be05676-c1bc-40cd-a5e6-77f58b584ee9.png"/>
<i><h2>7) Questions of Quiz Page </h2></i>
<img src="https://user-images.githubusercontent.com/97445870/183289932-ba457305-485e-4066-b0bd-ef2cc3be88b5.png"/>
<i><h2>8) Summary of User's answered and Correct Answer </h2></i>
<img src="https://user-images.githubusercontent.com/97445870/185743768-650a3b06-61a4-4833-a8e3-087ebe99759f.png"/>
<i><h2>9) Result Page it comes after user attempted the Quiz</h2></i>
<img src="https://user-images.githubusercontent.com/97445870/183289452-7109adfa-58f5-4412-87f7-bbaa0bf761a9.png"/>
<i><h2>10) Footer Page</h2></i>
<img src="https://user-images.githubusercontent.com/97445870/183289598-dd60cb2c-05df-4ae8-9048-b2f127d1122f.png"/>

